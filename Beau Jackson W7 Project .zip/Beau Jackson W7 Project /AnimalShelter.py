from pymongo import MongoClient
from pprint import pprint

class AnimalShelter:
    """CRUD Operations for Animal collection in MongoDB"""
    
    def __init__(self, user="aacuser", password="SNHU1234", db_name="AAC", collection_name="animals"):
        """Initialize MongoDB client and database"""
        try:
            self.client = MongoClient(f'mongodb://{user}:{password}@localhost:27017/{db_name}')
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
            print("Connection to MongoDB successful")
        except Exception as e:
            print(f"Could not connect to MongoDB: {e}")
            self.client = None
    
    def create(self, data):
        """Insert a new record into the database"""
        try:
            if data:
                result = self.collection.insert_one(data)
                pprint(result.inserted_id)
                print("Record created successfully")
                return True
            else:
                raise ValueError("Data to save cannot be empty")
        except Exception as e:
            print(f"An error occurred during record creation: {e}")
            return False
    
    def read(self, target=None):
        """Query the database and return matching records"""
        try:
            if target is None:
                target = {}  # If no target is provided, fetch all documents
            result = list(self.collection.find(target, {"_id": False}))
            if result:
                pprint(result)
            else:
                print("No matching documents found.")
            return result
        except Exception as e:
            print(f"An error occurred during record reading: {e}")
            return []
    
    def update(self, from_target, to_target, multiple=False):
        """Update records in the database"""
        try:
            if from_target:
                if multiple:
                    result = self.collection.update_many(from_target, to_target)
                else:
                    result = self.collection.update_one(from_target, to_target)
                
                pprint(f"Matched Count: {result.matched_count}, Modified Count: {result.modified_count}")
                if result.modified_count > 0:
                    print("Update successful!")
                    return True
                else:
                    print("No records updated")
                    return False
            else:
                raise ValueError("Update target cannot be empty")
        except Exception as e:
            print(f"An error occurred during record update: {e}")
            return False
    
    def delete(self, target, multiple=False):
        """Delete records from the database"""
        try:
            if target:
                if multiple:
                    result = self.collection.delete_many(target)
                else:
                    result = self.collection.delete_one(target)
                
                pprint(f"Deleted Count: {result.deleted_count}")
                if result.deleted_count > 0:
                    print("Deletion successful!")
                    return True
                else:
                    print("No records deleted")
                    return False
            else:
                raise ValueError("Delete target cannot be empty")
        except Exception as e:
            print(f"An error occurred during record deletion: {e}")
            return False

# Example usage
if __name__ == "__main__":
    shelter = AnimalShelter()  # Defaults to 'aacuser' and 'SNHU1234'
    
    if shelter.client:
        print("MongoDB Connection: Successful")
    else:
        print("MongoDB Connection: Failed")
    
    # Read all records
    all_animals = shelter.read()
    if not all_animals:
        print("No data found.")
    else:
        pprint(all_animals)